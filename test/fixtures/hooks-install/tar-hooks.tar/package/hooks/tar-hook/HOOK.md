---
name: tar-hook
description: tar-hook
metadata: {"nyxclaw":{"events":["command:new"]}}
---

# Hook