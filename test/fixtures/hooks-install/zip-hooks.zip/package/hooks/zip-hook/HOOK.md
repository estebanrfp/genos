---
name: zip-hook
description: Zip hook
metadata: {"nyxclaw":{"events":["command:new"]}}
---

# Zip Hook