---
name: reserved-hook
description: reserved-hook
metadata: {"nyxclaw":{"events":["command:new"]}}
---

# Hook