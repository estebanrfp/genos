---
name: one-hook
description: One hook
metadata: {"nyxclaw":{"events":["command:new"]}}
---

# One Hook