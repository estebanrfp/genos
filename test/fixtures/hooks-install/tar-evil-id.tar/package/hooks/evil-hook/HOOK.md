---
name: evil-hook
description: evil-hook
metadata: {"nyxclaw":{"events":["command:new"]}}
---

# Hook